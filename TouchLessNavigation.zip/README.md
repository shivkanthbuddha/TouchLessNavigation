# touchless-navigation

Uer navigates the website using gestures which are captured by the Web Camera 

inspired by https://aralroca.github.io/fishFollow-posenet-tfjs/ 

TensorflowJS with Posenet model.

## Getting start
* install node 
* `npm install`
* `npm start`

## DEMO

